<!-- Footer from https://mdbootstrap.com/docs/jquery/navigation/footer/ -->
<footer class="page-footer font-small bg-footer">

    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">
        &copy; 2020 Copyright!
    </div>
    <!-- Copyright -->

</footer>
<!-- Footer -->

<!-- include our custom js library -->
<script src="js/scripts.js" type="text/javascript"></script>

</body>
</html>
